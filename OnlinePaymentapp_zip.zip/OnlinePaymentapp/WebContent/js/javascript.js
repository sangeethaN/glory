/**
 *
 * 
 */
function show()
{
                document.getElementById("register form").hidden=false; 
}
function noregisteration()
{
                var x;
                if(confirm("we woule like you to register always.Please press ok to register and cancel to register without register without interest!")==true)
                {
                                x="You pressed ok!";
                }
                else
                {
                                x="you pressed cancel!";
                }
                document.getElementById("idButtonNo").disabled=true;
                
                
}


//document.getElementById("regform").innerHTML =false;