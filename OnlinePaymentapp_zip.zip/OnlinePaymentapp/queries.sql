create table t_xbbnhhn_dummy (entity varchar(100),type varchar(100));

insert into t_xbbnhhn_dummy values('policy 3','option 3');