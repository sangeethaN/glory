package Bank;

public class Bankdetails {
	private String bank_name,ac_holder,Ac_no,address,ph_no,branch_name;
	protected String password;
	private static double curr_balance;

	public Bankdetails(String bank_name,String ac_no, String ac_holder,String branch_name ,	String address, String ph_no,  String password) {
		super();
		this.bank_name = bank_name;
		this.ac_holder = ac_holder;
		Ac_no = ac_no;
		this.address = address;
		this.ph_no = ph_no;
		this.branch_name = branch_name;
		this.password = password;
	}

	public Bankdetails() {
		// TODO Auto-generated constructor stub
	}

	public String getBank_name() {
		return bank_name;
	}
	public String getAc_no() {
		return Ac_no;
	}
	public void setAc_no(String ac_no) {
		Ac_no = ac_no;
	}
	public String getBranch_name() {
		return branch_name;
	}
	public void setBranch_name(String branch_name) {
		this.branch_name = branch_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}
	public static double getCurr_balance() {
		return curr_balance;
	}
	public void setCurr_balance(double bal) {
		curr_balance=Transcations.getCurr_balance();
		this.curr_balance = curr_balance;
	}
	
	
	}
	


