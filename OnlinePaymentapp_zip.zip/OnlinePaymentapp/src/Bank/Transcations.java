package Bank;

public class Transcations extends Bankdetails {
private String Ac_no;
private double balance,curr_balance;
private Boolean bool;

private boolean withdraw(double amount) {
		if(this.balance>amount) {
		this.balance=this.balance-amount;
		bool=true;
	} else {
		bool=false;
	}
	super.setCurr_balance(this.balance);
	return bool;
}
private boolean deposit(double amount) {
	if(amount>99&&amount<200000) {
		this.balance=this.balance+amount;
		bool=true;
		}
		else {
		bool=false;
		}
	super.setCurr_balance(this.balance);
	return bool;
}
public boolean transfer(double amount) {
	if(amount>99&&amount<200000&&amount<(curr_balance-1000))
	{
		curr_balance=curr_balance-amount;
		bool=true;
	}else{
		bool=false;
	}
	super.setCurr_balance(this.balance);
	return bool;
}
}
