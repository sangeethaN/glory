package com;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;

	public class DBconnection {

		public Connection getConnection(){
			try{
				Class.forName("org.apache.derby.jdbc.ClientDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
			Connection con=null;
			try {
				 con=DriverManager.getConnection("jdbc:derby://172.24.18.54:1527/inewton","glory","123");
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return con;
				//s1.close();
				//con.close();
				
	}
}
