package com;
import Bank.Bankdetails;

import java.sql.*;
import java.util.*;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.SessionAttributes;

import onlinepage.page;

public class DBinsertion {
	Connection con=null;
	Bankdetails bd=new Bankdetails(); 
	List<Bankdetails> list=new ArrayList<Bankdetails>();
	String bank_name,ac_holder, ac_no, address, branch_name, password;
	int ph_no;
	static String temp,temp1,temp2;
	String id,ph,o_id,mode,Ac_no,br_name;
	double total;
	public DBinsertion() {
		super();
		DBconnection d=new DBconnection();
		con=d.getConnection();
		 
	}
	
     
	public void  insert(Online_pay bean) throws SQLException{
		try{
			id=bean.getId();
			temp=id;
			
			 ph_no=bean.getPh_no();
			 o_id=bean.getOrder_id();
			 temp1=o_id;
			 total=bean.getTotal_cost();
			 mode=bean.getPayment_mode();
			 Ac_no=bean.getAc_no();
			 temp2=Ac_no;
			 br_name=bean.getBranch_name();
			PreparedStatement ps = con.prepareStatement("insert into t_page values(?,?,?,?,?,?,?)");
			ps.setString(1,id);
			ps.setLong(2,ph_no);
			ps.setString(3,o_id);
			ps.setDouble(4,total);
			ps.setString(5,mode);
			ps.setString(6,Ac_no);
			ps.setString(7,br_name);
			int rs=ps.executeUpdate();
		}
		catch (NullPointerException e){
			System.out.println(e);
		}
	}
	public List retrieve(page p) throws SQLException{
		try{
			PreparedStatement p1 = con.prepareStatement("select * from t_Bankdetail where Ac_no=?");
			p1.setString(1,p.getAc_no());
			ResultSet rs=p1.executeQuery();
			while(rs.next())
			{
				bank_name=rs.getString("b_name");
				ac_holder=rs.getString("Ac_holder");
				ac_no=rs.getString("Ac_no");
				address=rs.getString("Address");
				ph_no=rs.getInt("ph_no");
				branch_name=rs.getString("b_branch");
				password=rs.getString("password");
			//	System.out.println(ac_holder+"hhh");
			bd=new Bankdetails(bank_name, ac_no,ac_holder, branch_name,address,(""+ ph_no),   password);
			list.add(bd);
			}
			
		}
		catch (Exception e){
			System.out.println( e);
		}
		return(list);
	}
	
	public void update(double total){
	try{
	//	System.out.println(temp+"ggg");
		PreparedStatement p1 = con.prepareStatement("insert into t_transactions values('"+temp+"','"+temp1+"',470.0)");
		PreparedStatement p2=con.prepareStatement("insert into t_details (u_id,dth_recharge) values ('"+temp2+"',470.0)");
					int rs1=p1.executeUpdate();
					int rs2=p2.executeUpdate();
				}
	catch(Exception e){
		System.out.println(e);
	}
	}

	public int insert_wallet(Online_pay d1) {
		int rs=0;
		try{
			
			DBconnection d=new DBconnection();
			Connection con=d.getConnection();
	
			PreparedStatement p1 = con.prepareStatement("insert into t_details (u_id,wallet) values (?,?)");
			p1.setString(1,id);
			p1.setDouble(2,d1.getWallet_amount());
			System.out.println(id+"  "+d1.getWallet_amount());
			rs=p1.executeUpdate();
		
  			}
		
catch (Exception e) {

		e.printStackTrace();
	}
		return rs;
	}
	
	
}
