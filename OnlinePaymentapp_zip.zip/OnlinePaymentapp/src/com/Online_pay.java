package com;

public class Online_pay {
	private String id,order_id,payment_mode,bank_name,Ac_no,Ac_branch;
	int ph_no;
	double COD,total_cost=0,wallet_amount;
	private String ac_holder,address,branch_name;
	private double curr_balance;
	private int no_of_item=4;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getPh_no() {
		return ph_no;
	}
	public void setPh_no(int ph_no) {
		this.ph_no = ph_no;
	}
	public String getOrder_id() {
		return order_id;
	}

	public double getWallet_amount() {
		return wallet_amount;
	}
	public void setWallet_amount(double wallet_amount) {
		this.wallet_amount = wallet_amount;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	public String getPayment_mode() {
		return payment_mode;
	}
	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}
	public String getBank_name() {
		return bank_name;
	}
	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}
	public String getAc_no() {
		return Ac_no;
	}
	public void setAc_no(String ac_no) {
		Ac_no = ac_no;
	}
	public String getAc_branch() {
		return Ac_branch;
	}
	public void setAc_branch(String ac_branch) {
		Ac_branch = ac_branch;
	}
	public double getCOD() {
		return COD;
	}
	public void setCOD(double cOD) {
		COD = cOD;
	}
	public double getTotal_cost() {
		return total_cost;
	}
	public void setTotal_cost(double total_cost) {
		this.total_cost = total_cost;
	}
	public String getAc_holder() {
		return ac_holder;
	}
	public void setAc_holder(String ac_holder) {
		this.ac_holder = ac_holder;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getBranch_name() {
		return branch_name;
	}
	public void setBranch_name(String branch_name) {
		this.branch_name = branch_name;
	}
	public double getCurr_balance() {
		return curr_balance;
	}
	public void setCurr_balance(double curr_balance) {
		this.curr_balance = curr_balance;
	}
	public int getNo_of_item() {
		return no_of_item;
	}
	public void setNo_of_item(int no_of_item) {
		this.no_of_item = no_of_item;
	}
	
}
