package com;

import java.sql.SQLException;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/payment")
public class UserController {

	@RequestMapping(value = "/insert", method = RequestMethod.PUT)
public int   userdetails(@RequestBody Online_pay d1 ) throws SQLException 
{
		DBinsertion db=new DBinsertion();
		int d=0;
		d=db.insert_wallet(d1);
		return d;
	
}

}