package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class counthits
 */
@WebServlet("/counthits")
public class counthits extends HttpServlet {
	int final_count;
	private static final long serialVersionUID = 1L;       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public counthits() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String name = request.getParameter("n"); 
        response.setContentType("text/html");
	    HttpSession session = request.getSession(true);
		Integer count = (Integer)session.getAttribute("tracker.count"); 
		if (count == null) 
		count = new Integer(1); 
		else 
		count = new Integer(count.intValue() + 1); 
		session.setAttribute("tracker.count", count); 
		out.print("Currently viewing : "+count);
		RequestDispatcher rd=request.getRequestDispatcher("frontpage.html");  
		rd.include(request, response); 
		setFinal_count(count);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	public int getFinal_count() {
		return final_count;
	}

	public void setFinal_count(int final_count) {
		this.final_count = final_count;
	}

}
