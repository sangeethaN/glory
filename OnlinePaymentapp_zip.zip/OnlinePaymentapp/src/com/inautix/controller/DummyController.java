package com.inautix.controller;

public class DummyController {
	

}
