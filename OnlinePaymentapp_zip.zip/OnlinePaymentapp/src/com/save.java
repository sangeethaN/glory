package com;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import onlinepage.page;
import cryptography.crypto;
import Bank.Bankdetails;
import Bank.Transcations;
@WebServlet("/save")
public class save extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public save() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");  
		 List<Bankdetails> list=new ArrayList<Bankdetails>();
		 PrintWriter out = response.getWriter();  
		Bankdetails b1=new Bankdetails();
		Online_pay bean=new Online_pay();  
		counthits ch=new counthits();
		crypto c1=new crypto();
		Transcations t1=new Transcations();
		com.DBinsertion d1=new com.DBinsertion();
		page p=new page();
	    String id, o_id=null,mode=null,ac_no ="", bn=null,captcha="",captcha_ans="qGphJD";
		int ph=0;
		double cost;
		 HttpSession session=request.getSession();  
		id=request.getParameter("id");
		
		session.setAttribute("user",id);

		ph=Integer.parseInt(request.getParameter("phone"));
	
		o_id=request.getParameter("o_id");
		// System.out.println(request.getParameter("o_id")+" O_id Save"+ph);
		cost=p.getTotal_cost();
		mode=request.getParameter("Payement Mode");
		ac_no=request.getParameter("Ac_no");
		bn=request.getParameter("bank");
		captcha=request.getParameter("c_ans");
		bean.setId(id);
		bean.setPh_no(ph);
		bean.setOrder_id(o_id);
		bean.setTotal_cost(cost);
		bean.setPayment_mode(mode);
		bean.setAc_no(ac_no);
		bean.setBranch_name(bn);
		page p1=new page(id,""+ph,o_id,mode,ac_no,bn);
		response.setHeader("Cache-Control", "no-cache"); //Forces caches to obtain a new copy of the page from the origin server
		response.setHeader("Cache-Control", "no-store"); //Directs caches not to store the page under any circumstance
	    response.setDateHeader("Expires", 0); //Causes the proxy cache to see the page as "stale"
		response.setHeader("Pragma", "no-cache"); //HTTP 1.0 backward compatibility
		String User=(String) session.getAttribute("user");
		System.out.println("user "+User);

try
{
	Connection con=null;
		DBconnection d=new DBconnection();
		con=d.getConnection();
		
		PreparedStatement ps = con.prepareStatement("select u_id from t_details where u_id=?");
		ps.setString(1, User);
		ResultSet rs = ps.executeQuery();
		String user_id;
		if(rs.next()) {
				d1.insert(bean);
				list=d1.retrieve(p1);
				for(Bankdetails b2:list)
				if(captcha.equals(captcha_ans)&&p.checkBankDetails(bn,ac_no,p1)&&c1.pw_check(request.getParameter("pw"))){
			      				d1.update(750.0);
			      				RequestDispatcher rd=request.getRequestDispatcher("front2.html");  
			      				rd.forward(request, response);			
							}else {
								
								RequestDispatcher rd=request.getRequestDispatcher("front3.html");  
								rd.forward(request, response);  
							}
		}
		else{
			out.print("<h2>Incorrect Username</h2>");
			RequestDispatcher rd=request.getRequestDispatcher("frontpage.jsp");  
			rd.include(request, response); 
		}
}catch (Exception e) {
	
	e.printStackTrace();
}}
}
