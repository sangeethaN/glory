package com;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import onlinepage.page;
import Bank.Bankdetails;
import Bank.Transcations;
import cryptography.crypto;

@WebServlet("/save_pw")
public class save_pw extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public save_pw() {
        super();
     
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");  
		 List<Bankdetails> list=new ArrayList<Bankdetails>();
		 PrintWriter out = response.getWriter();  
		Bankdetails b1=new Bankdetails();
		Transcations t1=new Transcations();
		page p1=new page();
		DBinsertion DB1=new DBinsertion();
		Online_pay bean=new Online_pay();  
		counthits ch=new counthits();
		crypto c1=new crypto();
		com.DBinsertion d1=new com.DBinsertion();
		page p=new page();
		if(c1.pw_check(request.getParameter("pw"))){
	      			System.out.println(t1.transfer(750.0));
					DB1.update(750.0);
				
					RequestDispatcher rd=request.getRequestDispatcher("otp_page.jsp");  
					rd.forward(request, response);			
		}
		else{
			//out.print("\t\t\t\t\t\t\tSorry Incorrect Details...!" );  
			RequestDispatcher rd=request.getRequestDispatcher("front3.html");  
			rd.include(request, response);  
		}
	}

}
