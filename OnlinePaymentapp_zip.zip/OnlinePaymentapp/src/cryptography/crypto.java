package cryptography;

import java.sql.SQLException;
import java.util.*;

import com.DBinsertion;

import onlinepage.page;
import Bank.Bankdetails;

public class crypto extends Bankdetails{
	protected String en_bankname,en_Ac_no,en_password,en_key,temp;
	Bankdetails b1;
	List<Bankdetails> list=new ArrayList<Bankdetails>();
	
	public String encryption(String bank_name2,String ac_no2) {
        char[] List  = (bank_name2+ac_no2).toCharArray();        
        StringBuilder result = new StringBuilder();
        String temp="";
        int maxCount =(bank_name2+ac_no2).length();
        int i = 0;
        for (Character a : List) {
             int key = Character.getNumericValue(List[i]);
                if(key % 2 == 0)
                    {
                      int res = a+key;
                      result.append((char)res);
                    }
                    else
                    {
                       int res = a-key;
                      result.append((char)res);
                    }
                 i++;
                 if(i==maxCount)
                 {
                    i = 0;
                 }
             }
         temp=temp+result;
		return temp;
	}
	

	private String encry_pw(String pw1) {
		char[] List  = pw1.toCharArray();        
        StringBuilder result = new StringBuilder();
        String temp="";
        int maxCount =pw1.length();
        //System.out.println("The length is enetrpw"+maxCount);
        int i = 0;

        for (Character a : List) {

             int key = Character.getNumericValue(List[i]);

                 if(key % 2 == 0)
                    {
                      int res = a+key;
                      result.append((char)res);
                    }
                    else
                    {
                       int res = a-key;
                      result.append((char)res);
                    }
                 i++;
                 if(i==maxCount)
                 {
                    i = 0;
                 }
             }
         System.out.println("The entered password is "+List+"  "+result.toString());
         temp=temp+result;
		return temp;
	}

	
	public Boolean check_encrypted(String bank_name2,String ac_no2,page p1) throws SQLException {
		
		Boolean bool=false;
		String str1,str2;
		str1=encryption(bank_name2,ac_no2);
		DBinsertion db=new DBinsertion();
		list=db.retrieve(p1);
		for(Bankdetails b2:list)
		{
		str2=encryption(b2.getBank_name(),b2.getAc_no());
		if(str1.equals(str2))
			bool=true;
		}
		return bool;
	}
	
	public Boolean pw_check(String pw1) {
		Boolean bool =false;
		String str1,str2;
		str1=encry_pw(pw1);
		str2=encry_pw("password");
		
		if(str1.equals(str2))
			bool=true;
	
		return bool;
	}
	
}
