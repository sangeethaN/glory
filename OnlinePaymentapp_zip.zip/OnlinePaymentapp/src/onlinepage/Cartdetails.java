package onlinepage;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.DBconnection;

import Bank.Bankdetails;
import onlinepage.page;
public class Cartdetails extends Bankdetails{
	DBconnection d=new DBconnection();
	Connection con=d.getConnection();
	private String id,order_id,pmode;
	private int no_of_item=4;
	private double cost=862,discount=10,tax=2.4,delivary_charges=11.4,total_cost;
	public Cartdetails() {
		super();
		double total_cost=0;
	}
	
	public Cartdetails(	String id, String order_id, int total_cost,String mode) {
		
		this.id = id;
		this.order_id = order_id;
		this.total_cost =(double)total_cost;
		this.pmode=mode;
	}

	public double calculate(String u_id){
		try{
			total_cost=(cost*no_of_item)-((cost*discount)/100)+((cost*tax)/100)+delivary_charges;
			int cos=1500;
			cos=(int)total_cost;
			System.out.println(cos+" "+u_id);
			super.setCurr_balance(total_cost);
			PreparedStatement ps = con.prepareStatement("update t_cart set total=?");
			ps.setInt(1,cos);
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		return total_cost;
	}

	public String getOrder_id() {
		return order_id;
	}

	public String getPmode() {
		return pmode;
	}

	public void setPmode(String pmode) {
		this.pmode = pmode;
	}

	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}

	public String getId() {
		return id;
	}

	public double getTotal_cost() {
		return total_cost;
	}
	}
