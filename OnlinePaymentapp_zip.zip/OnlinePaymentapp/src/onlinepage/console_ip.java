package onlinepage;
import Bank.Bankdetails;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import com.DBconnection;
import com.Online_pay;
public class console_ip {
	public static void main(String args[]) throws Exception{
		
		
		page p=new page();
		DBconnection d=new DBconnection();
		Cartdetails c1=new Cartdetails();
		Connection con=null;
		con=d.getConnection();
		Bankdetails b1=new Bankdetails();
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		String id,ph_no,order_id,payment_mode,bank_name,Ac_no;
		
		System.out.println("Enter the User ID");
		id=bf.readLine();
		System.out.println("Enter the Phone no");
		ph_no=bf.readLine();
		System.out.println("Enter the Order ID");
		order_id=bf.readLine();
		System.out.println("Enter the Payment_mode");
		payment_mode=bf.readLine();
		System.out.println("Enter the Bank_name");
		bank_name=bf.readLine();
		System.out.println("Enter the Ac_no");
		Ac_no=bf.readLine();
		p=new page(id,ph_no,order_id,payment_mode,bank_name,Ac_no);
	//	p.checkBankDetails(bank_name,Ac_no);
		try{
			PreparedStatement ps = con.prepareStatement("insert into t_page values(?,?,?,?,?,?,?)");
			ps.setString(1,id);
			ps.setString(2,ph_no);
			ps.setString(3,order_id);
			ps.setDouble(4,c1.calculate(id));
			ps.setString(5,payment_mode);
			ps.setString(6,Ac_no);
			ps.setString(7,bank_name);
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			System.out.println("Something Went Wrong.. Try again later...!");
		}
	}
	
}
