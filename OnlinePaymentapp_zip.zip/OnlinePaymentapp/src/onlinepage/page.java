package onlinepage;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import Bank.Bankdetails;
import cryptography.crypto;

public class page extends crypto {
	BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
	private String id,ph_no,order_id,payment_mode,bank_name,Ac_no,Ac_branch;
	Bankdetails b1;
	private double COD,total_cost=0;
	private boolean bool=false;
	crypto c1=new crypto();
	public boolean checkBankDetails(String bank_name2, String ac_no2,page p2) throws Exception{
		if(c1.check_encrypted(bank_name2, ac_no2,p2))
			{
				bool=true;
			}
		else
			bool=false; 
		return bool;
	}
	
	public page() {
		super();
	}

	public page(String id, String ph_no, String order_id, String payment_mode,String Ac_no,String bank_name) {
		super();
		this.id = id;
		this.ph_no = ph_no;
		this.order_id = order_id;
		this.payment_mode = payment_mode;
		this.bank_name = bank_name;
		this.Ac_no=Ac_no;
	}
	
	public page(String bank_name, String ac_no, String ac_branch) throws Exception {
		super();
		this.bank_name = bank_name;
		Ac_branch = ac_branch;
		//checkBankDetails(bank_name,ac_no);
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	public void setPh_no(String ph_no) {
		this.ph_no = ph_no;
	}
	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}
	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}
	public void setCOD(double cOD) {
		COD = cOD;
	}
	public double  getTotal_cost() {
		return total_cost;
	}
	
	public String getAc_no() {
		return Ac_no;
	}

	public void setAc_no(String ac_no) {
		Ac_no = ac_no;
	}

	public void setTotal_cost(double total_cost) {
		this.total_cost = total_cost;
	}
	
	
}
